const blockfrostApiKey = {
    0: "testnetKQbRyYNFoszeZMEir4duRzAQ1gA71SbI", // testnet
    1: "mainnetIbYG7wECGWgG87xegwxQAGJfAKhh5C4r" // mainnet
}

export default blockfrostApiKey;